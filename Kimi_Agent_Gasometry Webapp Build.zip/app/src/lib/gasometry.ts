export interface GasometryInput {
  ph: number | null
  paco2: number | null
  pao2: number | null
  hco3: number | null
  be: number | null
  sao2: number | null
  na: number | null
  k: number | null
  cl: number | null
  ca: number | null
  lactate: number | null
  glucose: number | null
  hb: number | null
  albumin: number | null
  fio2: number | null
  temperature: number | null
}

export interface AcidBaseResult {
  primaryDisorder: string
  phStatus: 'acidemia' | 'alkalemia' | 'normal'
  disorderType: string
  compensation: string
  compensationExpected: string
  compensationAppropriate: boolean
  mixedDisorder: boolean
  anionGap: number | null
  correctedAnionGap: number | null
  deltaRatio: number | null
  deltaHco3: number | null
  winterPrediction: number | null
  interpretation: string[]
}

export interface OxygenationResult {
  aaGradient: number | null
  aaGradientExpected: number | null
  aaGradientElevated: boolean
  paO2: number | null
  pfRatio: number | null
  oxygenationStatus: string
  shuntFraction: number | null
  oxygenationInterpretation: string[]
}

export interface ElectrolyteResult {
  anionGap: number | null
  correctedAnionGap: number | null
  osmolarGap: number | null
  electrolyteInterpretation: string[]
}

export interface SeverityScore {
  totalScore: number
  severity: 'Mild' | 'Moderate' | 'Severe' | 'Critical'
  riskClass: string
  mortalityRisk: string
  components: { name: string; score: number; maxScore: number }[]
}

export interface GasometryResult {
  acidBase: AcidBaseResult
  oxygenation: OxygenationResult
  electrolytes: ElectrolyteResult
  severity: SeverityScore
  overallInterpretation: string[]
}

const NORMAL_RANGES = {
  ph: { min: 7.35, max: 7.45 },
  paco2: { min: 35, max: 45 },
  pao2: { min: 80, max: 100 },
  hco3: { min: 22, max: 26 },
  be: { min: -2, max: 2 },
  sao2: { min: 95, max: 100 },
  na: { min: 135, max: 145 },
  k: { min: 3.5, max: 5.0 },
  cl: { min: 98, max: 106 },
  ca: { min: 2.2, max: 2.6 },
  lactate: { min: 0.5, max: 1.6 },
  glucose: { min: 70, max: 100 },
  hb: { min: 12, max: 16 },
  albumin: { min: 3.5, max: 5.0 },
  fio2: { min: 21, max: 100 },
  temperature: { min: 36.5, max: 37.5 },
}

export function calculateAnionGap(na: number, cl: number, hco3: number): number {
  return na - (cl + hco3)
}

export function calculateCorrectedAnionGap(ag: number, albumin: number): number {
  return ag + 2.5 * (4 - albumin)
}

export function calculateDeltaRatio(deltaAG: number, deltaHCO3: number): number | null {
  if (deltaHCO3 === 0) return null
  return deltaAG / deltaHCO3
}

export function calculatePAO2(fio2: number, paco2: number, altitude: number = 0): number {
  const pb = 760 - altitude * 0.87
  const ph2o = 47
  const rq = 0.8
  return (fio2 / 100) * (pb - ph2o) - (paco2 / rq)
}

export function calculateAaGradient(pao2: number, pao2_calc: number): number {
  return pao2_calc - pao2
}

export function calculateExpectedAaGradient(age: number): number {
  return (age / 4) + 4
}

export function calculatePFRatio(pao2: number, fio2: number): number | null {
  if (!fio2 || fio2 === 0) return null
  return pao2 / (fio2 / 100)
}

export function calculateShuntFraction(
  pao2: number,
  pao2_calc: number,
  fio2: number
): number | null {
  if (!pao2_calc || pao2_calc === 0) return null
  const a = (fio2 / 100) * (760 - 47)
  if (a === 0) return null
  return ((pao2_calc - pao2) * 0.003) / (a + (pao2_calc - pao2) * 0.003)
}

export function wintersFormula(hco3: number): number {
  return 1.5 * hco3 + 8
}

export function expectedPaCO2ForMetabolicAcidosis(hco3: number): { min: number; max: number } {
  const expected = 1.5 * hco3 + 8
  return { min: expected - 2, max: expected + 2 }
}

export function expectedHCO3ForRespiratoryAcidosis(
  paco2: number,
  acute: boolean
): { min: number; max: number } {
  const deltaPaCO2 = paco2 - 40
  if (acute) {
    const expected = 24 + deltaPaCO2 * 0.1
    return { min: expected - 2, max: expected + 2 }
  } else {
    const expected = 24 + deltaPaCO2 * 0.35
    return { min: expected - 3, max: expected + 3 }
  }
}

export function expectedHCO3ForRespiratoryAlkalosis(
  paco2: number,
  acute: boolean
): { min: number; max: number } {
  const deltaPaCO2 = 40 - paco2
  if (acute) {
    const expected = 24 - deltaPaCO2 * 0.2
    return { min: expected - 2, max: expected + 2 }
  } else {
    const expected = 24 - deltaPaCO2 * 0.5
    return { min: expected - 3, max: expected + 3 }
  }
}

export function expectedPaCO2ForMetabolicAlkalosis(hco3: number): { min: number; max: number } {
  const expected = 40 + 0.7 * (hco3 - 24)
  return { min: expected - 2, max: expected + 2 }
}

export function calculateOsmolarGap(
  na: number,
  glucose: number,
  bun: number | null,
  measuredOsm: number | null
): number | null {
  if (!measuredOsm) return null
  const calculatedOsm = 2 * na + glucose / 18 + (bun ? bun / 2.8 : 0)
  return measuredOsm - calculatedOsm
}

export function interpretGasometry(input: GasometryInput): GasometryResult {
  const acidBase = interpretAcidBase(input)
  const oxygenation = interpretOxygenation(input)
  const electrolytes = interpretElectrolytes(input)
  const severity = calculateSeverityScore(input, acidBase, oxygenation)

  const overallInterpretation: string[] = []

  if (acidBase.primaryDisorder !== 'Normal') {
    overallInterpretation.push(`Primary acid-base disorder: ${acidBase.primaryDisorder}`)
  }

  if (acidBase.mixedDisorder) {
    overallInterpretation.push('Mixed acid-base disorder detected')
  }

  if (oxygenation.aaGradientElevated) {
    overallInterpretation.push('Elevated A-a gradient suggests V/Q mismatch or shunt')
  }

  if (severity.severity === 'Critical' || severity.severity === 'Severe') {
    overallInterpretation.push(`High severity score (${severity.totalScore}): ${severity.mortalityRisk}`)
  }

  return {
    acidBase,
    oxygenation,
    electrolytes,
    severity,
    overallInterpretation,
  }
}

function interpretAcidBase(input: GasometryInput): AcidBaseResult {
  const { ph, paco2, hco3, be, na, cl, albumin } = input

  let phStatus: 'acidemia' | 'alkalemia' | 'normal' = 'normal'
  let primaryDisorder = 'Normal'
  let disorderType = 'Normal acid-base balance'
  let compensation = 'Not applicable'
  let compensationExpected = ''
  let compensationAppropriate = true
  let mixedDisorder = false
  let anionGap: number | null = null
  let correctedAnionGap: number | null = null
  let deltaRatio: number | null = null
  let deltaHco3: number | null = null
  let winterPrediction: number | null = null
  const interpretation: string[] = []

  if (!ph || !paco2 || !hco3) {
    return {
      primaryDisorder: 'Insufficient data',
      phStatus: 'normal',
      disorderType: 'Insufficient data for interpretation',
      compensation: 'Not applicable',
      compensationExpected: '',
      compensationAppropriate: false,
      mixedDisorder: false,
      anionGap,
      correctedAnionGap,
      deltaRatio,
      deltaHco3,
      winterPrediction,
      interpretation: ['Please provide pH, PaCO2, and HCO3 for acid-base analysis'],
    }
  }

  if (ph < 7.35) phStatus = 'acidemia'
  else if (ph > 7.45) phStatus = 'alkalemia'

  if (na && cl && hco3) {
    anionGap = calculateAnionGap(na, cl, hco3)
    if (albumin) {
      correctedAnionGap = calculateCorrectedAnionGap(anionGap, albumin)
    }
  }

  const normalAG = 12
  const isHighAG = (correctedAnionGap ?? anionGap ?? 0) > 16
  const isNormalAG = (correctedAnionGap ?? anionGap ?? 0) >= 8 && (correctedAnionGap ?? anionGap ?? 0) <= 16

  if (phStatus === 'acidemia') {
    if (paco2 > 45 && hco3 >= 22) {
      primaryDisorder = 'Respiratory Acidosis'
      disorderType = 'Primary respiratory acidosis'
      const acuteExp = expectedHCO3ForRespiratoryAcidosis(paco2, true)
      const chronicExp = expectedHCO3ForRespiratoryAcidosis(paco2, false)

      if (hco3 >= acuteExp.min && hco3 <= acuteExp.max) {
        compensation = 'Acute respiratory acidosis (appropriate compensation)'
        compensationExpected = `Expected HCO3: ${acuteExp.min.toFixed(1)}-${acuteExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = true
      } else if (hco3 >= chronicExp.min && hco3 <= chronicExp.max) {
        compensation = 'Chronic respiratory acidosis (appropriate compensation)'
        compensationExpected = `Expected HCO3: ${chronicExp.min.toFixed(1)}-${chronicExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = true
      } else if (hco3 > chronicExp.max) {
        compensation = 'Respiratory acidosis with metabolic alkalosis (mixed disorder)'
        compensationExpected = `Expected HCO3: ${chronicExp.min.toFixed(1)}-${chronicExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = false
        mixedDisorder = true
      } else {
        compensation = 'Respiratory acidosis with incomplete compensation'
        compensationExpected = `Expected HCO3 (acute): ${acuteExp.min.toFixed(1)}-${acuteExp.max.toFixed(1)} mEq/L, (chronic): ${chronicExp.min.toFixed(1)}-${chronicExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = false
      }
    } else if (hco3 < 22) {
      primaryDisorder = 'Metabolic Acidosis'
      disorderType = 'Primary metabolic acidosis'

      if (isHighAG) {
        disorderType = 'High anion gap metabolic acidosis'
        if (anionGap !== null && hco3 !== null) {
          deltaHco3 = 24 - hco3
          const deltaAG = (anionGap ?? 0) - normalAG
          deltaRatio = calculateDeltaRatio(deltaAG, deltaHco3)

          if (deltaRatio !== null) {
            if (deltaRatio < 0.4) {
              disorderType = 'High AG metabolic acidosis with non-AG metabolic acidosis'
              mixedDisorder = true
            } else if (deltaRatio > 2) {
              disorderType = 'High AG metabolic acidosis with metabolic alkalosis'
              mixedDisorder = true
            }
          }
        }
      } else if (isNormalAG) {
        disorderType = 'Normal anion gap metabolic acidosis'
      }

      winterPrediction = wintersFormula(hco3)
      const expectedPaCO2 = expectedPaCO2ForMetabolicAcidosis(hco3)

      if (paco2 >= expectedPaCO2.min && paco2 <= expectedPaCO2.max) {
        compensation = 'Appropriate respiratory compensation'
        compensationExpected = `Expected PaCO2: ${expectedPaCO2.min.toFixed(1)}-${expectedPaCO2.max.toFixed(1)} mmHg (Winter\'s formula)`
        compensationAppropriate = true
      } else if (paco2 < expectedPaCO2.min) {
        compensation = 'Metabolic acidosis with respiratory alkalosis (mixed disorder)'
        compensationExpected = `Expected PaCO2: ${expectedPaCO2.min.toFixed(1)}-${expectedPaCO2.max.toFixed(1)} mmHg`
        compensationAppropriate = false
        mixedDisorder = true
      } else {
        compensation = 'Inadequate respiratory compensation'
        compensationExpected = `Expected PaCO2: ${expectedPaCO2.min.toFixed(1)}-${expectedPaCO2.max.toFixed(1)} mmHg`
        compensationAppropriate = false
      }
    } else {
      primaryDisorder = 'Mixed Acidosis'
      disorderType = 'Combined respiratory and metabolic acidosis'
      mixedDisorder = true
    }
  } else if (phStatus === 'alkalemia') {
    if (paco2 < 35 && hco3 <= 26) {
      primaryDisorder = 'Respiratory Alkalosis'
      disorderType = 'Primary respiratory alkalosis'
      const acuteExp = expectedHCO3ForRespiratoryAlkalosis(paco2, true)
      const chronicExp = expectedHCO3ForRespiratoryAlkalosis(paco2, false)

      if (hco3 >= acuteExp.min && hco3 <= acuteExp.max) {
        compensation = 'Acute respiratory alkalosis (appropriate compensation)'
        compensationExpected = `Expected HCO3: ${acuteExp.min.toFixed(1)}-${acuteExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = true
      } else if (hco3 >= chronicExp.min && hco3 <= chronicExp.max) {
        compensation = 'Chronic respiratory alkalosis (appropriate compensation)'
        compensationExpected = `Expected HCO3: ${chronicExp.min.toFixed(1)}-${chronicExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = true
      } else if (hco3 < chronicExp.min) {
        compensation = 'Respiratory alkalosis with metabolic acidosis (mixed disorder)'
        compensationExpected = `Expected HCO3: ${chronicExp.min.toFixed(1)}-${chronicExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = false
        mixedDisorder = true
      } else {
        compensation = 'Respiratory alkalosis with incomplete compensation'
        compensationExpected = `Expected HCO3 (acute): ${acuteExp.min.toFixed(1)}-${acuteExp.max.toFixed(1)} mEq/L, (chronic): ${chronicExp.min.toFixed(1)}-${chronicExp.max.toFixed(1)} mEq/L`
        compensationAppropriate = false
      }
    } else if (hco3 > 26) {
      primaryDisorder = 'Metabolic Alkalosis'
      disorderType = 'Primary metabolic alkalosis'
      const expectedPaCO2 = expectedPaCO2ForMetabolicAlkalosis(hco3)

      if (paco2 >= expectedPaCO2.min && paco2 <= expectedPaCO2.max) {
        compensation = 'Appropriate respiratory compensation'
        compensationExpected = `Expected PaCO2: ${expectedPaCO2.min.toFixed(1)}-${expectedPaCO2.max.toFixed(1)} mmHg`
        compensationAppropriate = true
      } else if (paco2 > expectedPaCO2.max) {
        compensation = 'Metabolic alkalosis with respiratory acidosis (mixed disorder)'
        compensationExpected = `Expected PaCO2: ${expectedPaCO2.min.toFixed(1)}-${expectedPaCO2.max.toFixed(1)} mmHg`
        compensationAppropriate = false
        mixedDisorder = true
      } else {
        compensation = 'Inadequate respiratory compensation'
        compensationExpected = `Expected PaCO2: ${expectedPaCO2.min.toFixed(1)}-${expectedPaCO2.max.toFixed(1)} mmHg`
        compensationAppropriate = false
      }
    } else {
      primaryDisorder = 'Mixed Alkalosis'
      disorderType = 'Combined respiratory and metabolic alkalosis'
      mixedDisorder = true
    }
  } else {
    if (paco2 > 45 && hco3 > 26) {
      primaryDisorder = 'Compensated Respiratory Acidosis'
      disorderType = 'Fully compensated respiratory acidosis'
      compensation = 'Metabolic compensation has normalized pH'
    } else if (paco2 < 35 && hco3 < 22) {
      primaryDisorder = 'Compensated Respiratory Alkalosis'
      disorderType = 'Fully compensated respiratory alkalosis'
      compensation = 'Metabolic compensation has normalized pH'
    } else if (hco3 > 26 && paco2 > 45) {
      primaryDisorder = 'Compensated Metabolic Alkalosis'
      disorderType = 'Fully compensated metabolic alkalosis'
      compensation = 'Respiratory compensation has normalized pH'
    } else if (hco3 < 22 && paco2 < 35) {
      primaryDisorder = 'Compensated Metabolic Acidosis'
      disorderType = 'Fully compensated metabolic acidosis'
      compensation = 'Respiratory compensation has normalized pH'
    }
  }

  if (anionGap !== null) {
    interpretation.push(`Anion Gap: ${anionGap.toFixed(1)} mEq/L`)
    if (correctedAnionGap !== null) {
      interpretation.push(`Corrected Anion Gap (for albumin ${albumin} g/dL): ${correctedAnionGap.toFixed(1)} mEq/L`)
    }
    if (deltaRatio !== null) {
      interpretation.push(`Delta Ratio: ${deltaRatio.toFixed(2)}`)
      if (deltaRatio < 0.4) interpretation.push('Delta ratio < 0.4 suggests combined high AG + normal AG acidosis')
      else if (deltaRatio >= 0.4 && deltaRatio <= 2) interpretation.push('Delta ratio 0.4-2.0 suggests pure high AG metabolic acidosis')
      else interpretation.push('Delta ratio > 2.0 suggests combined high AG acidosis + metabolic alkalosis')
    }
  }

  if (winterPrediction !== null) {
    interpretation.push(`Winter's formula predicts PaCO2 ≈ ${winterPrediction.toFixed(1)} ± 2 mmHg`)
  }

  if (be !== null) {
    if (be < -2) interpretation.push(`Base excess ${be.toFixed(1)} mEq/L confirms metabolic acidosis`)
    else if (be > 2) interpretation.push(`Base excess +${be.toFixed(1)} mEq/L confirms metabolic alkalosis`)
  }

  return {
    primaryDisorder,
    phStatus,
    disorderType,
    compensation,
    compensationExpected,
    compensationAppropriate,
    mixedDisorder,
    anionGap,
    correctedAnionGap,
    deltaRatio,
    deltaHco3,
    winterPrediction,
    interpretation,
  }
}

function interpretOxygenation(input: GasometryInput): OxygenationResult {
  const { pao2, paco2, fio2, temperature, hb } = input

  let aaGradient: number | null = null
  let aaGradientExpected: number | null = null
  let aaGradientElevated = false
  let paO2: number | null = null
  let pFRatio: number | null = null
  let oxygenationStatus = 'Normal oxygenation'
  let shuntFraction: number | null = null
  const oxygenationInterpretation: string[] = []

  if (!pao2) {
    return {
      aaGradient: null,
      aaGradientExpected: null,
      aaGradientElevated: false,
      paO2: null,
      pfRatio: null,
      oxygenationStatus: 'Insufficient data',
      shuntFraction: null,
      oxygenationInterpretation: ['Please provide PaO2 for oxygenation analysis'],
    }
  }

  if (fio2 && paco2) {
    paO2 = calculatePAO2(fio2, paco2)
    aaGradient = calculateAaGradient(pao2, paO2)
    aaGradientExpected = 15
    aaGradientElevated = aaGradient > aaGradientExpected

    if (aaGradientElevated) {
      oxygenationInterpretation.push(`Elevated A-a gradient: ${aaGradient.toFixed(1)} mmHg (expected < ${aaGradientExpected} mmHg)`)
      oxygenationInterpretation.push('Causes: V/Q mismatch, shunt, diffusion defect')
    } else {
      oxygenationInterpretation.push(`Normal A-a gradient: ${aaGradient.toFixed(1)} mmHg`)
    }

    shuntFraction = calculateShuntFraction(pao2, paO2, fio2)
    if (shuntFraction !== null) {
      oxygenationInterpretation.push(`Estimated shunt fraction: ${(shuntFraction * 100).toFixed(1)}%`)
    }
  }

  if (fio2) {
    pFRatio = calculatePFRatio(pao2, fio2)
    if (pFRatio !== null) {
      oxygenationInterpretation.push(`P/F Ratio: ${pFRatio.toFixed(0)} mmHg`)
      if (pFRatio >= 400) {
        oxygenationStatus = 'Normal oxygenation'
      } else if (pFRatio >= 300) {
        oxygenationStatus = 'Mild hypoxemia'
      } else if (pFRatio >= 200) {
        oxygenationStatus = 'Moderate hypoxemia (ARDS mild)'
      } else if (pFRatio >= 100) {
        oxygenationStatus = 'Severe hypoxemia (ARDS moderate)'
      } else {
        oxygenationStatus = 'Critical hypoxemia (ARDS severe)'
      }
    }
  }

  if (temperature) {
    if (temperature < 36) {
      oxygenationInterpretation.push('Hypothermia may shift oxyhemoglobin curve left, increasing affinity')
    } else if (temperature > 38) {
      oxygenationInterpretation.push('Hyperthermia may shift oxyhemoglobin curve right, decreasing affinity')
    }
  }

  if (hb) {
    if (hb < 12) {
      oxygenationInterpretation.push(`Anemia (Hb ${hb} g/dL) reduces oxygen-carrying capacity`)
    }
  }

  return {
    aaGradient,
    aaGradientExpected,
    aaGradientElevated,
    paO2,
    pfRatio: pFRatio,
    oxygenationStatus,
    shuntFraction,
    oxygenationInterpretation,
  }
}

function interpretElectrolytes(input: GasometryInput): ElectrolyteResult {
  const { na, k, cl, ca, lactate, glucose } = input

  let anionGap: number | null = null
  let correctedAnionGap: number | null = null
  let osmolarGap: number | null = null
  const electrolyteInterpretation: string[] = []

  if (na && cl && input.hco3) {
    anionGap = calculateAnionGap(na, cl, input.hco3)
    if (input.albumin) {
      correctedAnionGap = calculateCorrectedAnionGap(anionGap, input.albumin)
    }
  }

  if (k !== null) {
    if (k < 3.5) electrolyteInterpretation.push(`Hypokalemia (${k} mEq/L): consider replacement, monitor ECG`)
    else if (k > 5.0) electrolyteInterpretation.push(`Hyperkalemia (${k} mEq/L): urgent ECG, consider calcium, insulin/glucose`)
  }

  if (na !== null) {
    if (na < 135) electrolyteInterpretation.push(`Hyponatremia (${na} mEq/L): evaluate volume status, SIADH, diuretics`)
    else if (na > 145) electrolyteInterpretation.push(`Hypernatremia (${na} mEq/L): evaluate dehydration, DI, osmotic diuresis`)
  }

  if (ca !== null) {
    if (ca < 2.2) electrolyteInterpretation.push(`Hypocalcemia (${ca} mmol/L): check ionized calcium, replace if symptomatic`)
    else if (ca > 2.6) electrolyteInterpretation.push(`Hypercalcemia (${ca} mmol/L): evaluate malignancy, hyperparathyroidism`)
  }

  if (lactate !== null) {
    if (lactate > 2) {
      electrolyteInterpretation.push(`Elevated lactate (${lactate} mmol/L): indicates tissue hypoperfusion/type A lactic acidosis`)
      if (lactate > 4) electrolyteInterpretation.push('Severe hyperlactatemia: high mortality risk, aggressive resuscitation needed')
    }
  }

  if (glucose !== null) {
    if (glucose < 70) electrolyteInterpretation.push(`Hypoglycemia (${glucose} mg/dL): immediate glucose management`)
    else if (glucose > 180) electrolyteInterpretation.push(`Hyperglycemia (${glucose} mg/dL): consider insulin, evaluate DKA/HHS`)
  }

  return {
    anionGap,
    correctedAnionGap,
    osmolarGap,
    electrolyteInterpretation,
  }
}

function calculateSeverityScore(
  input: GasometryInput,
  acidBase: AcidBaseResult,
  oxygenation: OxygenationResult
): SeverityScore {
  const { ph, paco2, pao2, hco3, lactate, na, k } = input
  const components: { name: string; score: number; maxScore: number }[] = []
  let totalScore = 0

  // pH score (0-4)
  let phScore = 0
  if (ph !== null) {
    if (ph < 7.2 || ph > 7.6) phScore = 4
    else if (ph < 7.25 || ph > 7.55) phScore = 3
    else if (ph < 7.3 || ph > 7.5) phScore = 2
    else if (ph < 7.35 || ph > 7.45) phScore = 1
  }
  components.push({ name: 'pH', score: phScore, maxScore: 4 })
  totalScore += phScore

  // PaCO2 score (0-3)
  let paco2Score = 0
  if (paco2 !== null) {
    if (paco2 > 80 || paco2 < 20) paco2Score = 3
    else if (paco2 > 60 || paco2 < 30) paco2Score = 2
    else if (paco2 > 50 || paco2 < 35) paco2Score = 1
  }
  components.push({ name: 'PaCO2', score: paco2Score, maxScore: 3 })
  totalScore += paco2Score

  // HCO3 score (0-3)
  let hco3Score = 0
  if (hco3 !== null) {
    if (hco3 < 10 || hco3 > 40) hco3Score = 3
    else if (hco3 < 15 || hco3 > 35) hco3Score = 2
    else if (hco3 < 20 || hco3 > 30) hco3Score = 1
  }
  components.push({ name: 'HCO3', score: hco3Score, maxScore: 3 })
  totalScore += hco3Score

  // Oxygenation score (0-4)
  let oxyScore = 0
  if (oxygenation.pfRatio !== null) {
    if (oxygenation.pfRatio < 100) oxyScore = 4
    else if (oxygenation.pfRatio < 200) oxyScore = 3
    else if (oxygenation.pfRatio < 300) oxyScore = 2
    else if (oxygenation.pfRatio < 400) oxyScore = 1
  } else if (pao2 !== null) {
    if (pao2 < 40) oxyScore = 4
    else if (pao2 < 60) oxyScore = 3
    else if (pao2 < 80) oxyScore = 2
    else if (pao2 < 100) oxyScore = 1
  }
  components.push({ name: 'Oxygenation', score: oxyScore, maxScore: 4 })
  totalScore += oxyScore

  // Lactate score (0-4)
  let lactateScore = 0
  if (lactate !== null) {
    if (lactate > 8) lactateScore = 4
    else if (lactate > 4) lactateScore = 3
    else if (lactate > 2) lactateScore = 2
    else if (lactate > 1.6) lactateScore = 1
  }
  components.push({ name: 'Lactate', score: lactateScore, maxScore: 4 })
  totalScore += lactateScore

  // Electrolyte score (0-3)
  let electrolyteScore = 0
  if (na !== null) {
    if (na < 120 || na > 160) electrolyteScore = Math.max(electrolyteScore, 3)
    else if (na < 130 || na > 155) electrolyteScore = Math.max(electrolyteScore, 2)
    else if (na < 135 || na > 145) electrolyteScore = Math.max(electrolyteScore, 1)
  }
  if (k !== null) {
    if (k < 2.5 || k > 6.5) electrolyteScore = Math.max(electrolyteScore, 3)
    else if (k < 3 || k > 6) electrolyteScore = Math.max(electrolyteScore, 2)
    else if (k < 3.5 || k > 5) electrolyteScore = Math.max(electrolyteScore, 1)
  }
  components.push({ name: 'Electrolytes', score: electrolyteScore, maxScore: 3 })
  totalScore += electrolyteScore

  // Mixed disorder bonus
  if (acidBase.mixedDisorder) {
    components.push({ name: 'Mixed Disorder', score: 2, maxScore: 2 })
    totalScore += 2
  }

  const severity: 'Mild' | 'Moderate' | 'Severe' | 'Critical' =
    totalScore <= 3 ? 'Mild' :
    totalScore <= 7 ? 'Moderate' :
    totalScore <= 12 ? 'Severe' : 'Critical'

  const riskClass = totalScore <= 3 ? 'Low Risk' :
    totalScore <= 7 ? 'Moderate Risk' :
    totalScore <= 12 ? 'High Risk' : 'Very High Risk'

  const mortalityRisk =
    severity === 'Mild' ? 'Low mortality risk (< 5%)' :
    severity === 'Moderate' ? 'Moderate mortality risk (5-15%)' :
    severity === 'Severe' ? 'High mortality risk (15-40%)' :
    'Very high mortality risk (> 40%)'

  return {
    totalScore,
    severity,
    riskClass,
    mortalityRisk,
    components,
  }
}

export function getInputStatus(value: number | null, param: keyof typeof NORMAL_RANGES): 'normal' | 'low' | 'high' | 'unknown' {
  if (value === null) return 'unknown'
  const range = NORMAL_RANGES[param]
  if (value < range.min) return 'low'
  if (value > range.max) return 'high'
  return 'normal'
}

export { NORMAL_RANGES }
