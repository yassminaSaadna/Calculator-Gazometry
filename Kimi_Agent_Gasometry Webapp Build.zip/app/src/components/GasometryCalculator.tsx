import { useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { AlertTriangle, CheckCircle, Info, Droplets, Wind, Activity, FlaskConical, ChevronDown, ChevronUp } from 'lucide-react'
import {
  interpretGasometry,
  getInputStatus,
  NORMAL_RANGES,
  type GasometryInput,
  type GasometryResult,
} from '@/lib/gasometry'

interface InputFieldProps {
  label: string
  unit: string
  value: string
  onChange: (val: string) => void
  status: 'normal' | 'low' | 'high' | 'unknown'
  normalRange: string
  icon?: React.ReactNode
}

function InputField({ label, unit, value, onChange, status, normalRange, icon }: InputFieldProps) {
  const statusColors = {
    normal: 'border-emerald-500/50 focus:border-emerald-400',
    low: 'border-amber-500/50 focus:border-amber-400',
    high: 'border-red-500/50 focus:border-red-400',
    unknown: 'border-slate-600 focus:border-cyan-400',
  }

  const statusBadge = {
    normal: <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 text-xs">Normal</Badge>,
    low: <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30 text-xs">Low</Badge>,
    high: <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/30 text-xs">High</Badge>,
    unknown: null,
  }

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium text-slate-300 flex items-center gap-1.5">
          {icon && <span className="text-cyan-400/70">{icon}</span>}
          {label}
        </Label>
        <span className="text-xs text-slate-500">{unit}</span>
      </div>
      <div className="flex items-center gap-2">
        <Input
          type="number"
          step="0.1"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={`${normalRange}`}
          className={`bg-slate-900/80 border text-slate-200 placeholder:text-slate-600 h-9 transition-colors ${statusColors[status]}`}
        />
        {statusBadge[status]}
      </div>
      <p className="text-xs text-slate-500">Normal: {normalRange}</p>
    </div>
  )
}

function SectionCard({ title, icon, children, className = '' }: { title: string; icon: React.ReactNode; children: React.ReactNode; className?: string }) {
  const [expanded, setExpanded] = useState(true)
  return (
    <Card className={`bg-slate-900/60 border-slate-700/50 backdrop-blur-sm ${className}`}>
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold text-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-cyan-400">{icon}</span>
            {title}
          </div>
          <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)} className="h-7 w-7 p-0 text-slate-400 hover:text-slate-200">
            {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </CardTitle>
      </CardHeader>
      {expanded && <CardContent>{children}</CardContent>}
    </Card>
  )
}

function ScoreGauge({ score, maxScore, label, color }: { score: number; maxScore: number; label: string; color: string }) {
  const percentage = maxScore > 0 ? (score / maxScore) * 100 : 0
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-xs">
        <span className="text-slate-400">{label}</span>
        <span className={`font-medium ${color}`}>{score} / {maxScore}</span>
      </div>
      <Progress value={percentage} className="h-1.5 bg-slate-800" />
    </div>
  )
}

export default function GasometryCalculator() {
  const [input, setInput] = useState<GasometryInput>({
    ph: null,
    paco2: null,
    pao2: null,
    hco3: null,
    be: null,
    sao2: null,
    na: null,
    k: null,
    cl: null,
    ca: null,
    lactate: null,
    glucose: null,
    hb: null,
    albumin: null,
    fio2: null,
    temperature: null,
  })

  const [result, setResult] = useState<GasometryResult | null>(null)

  const updateField = useCallback((field: keyof GasometryInput, value: string) => {
    const numVal = value === '' ? null : parseFloat(value)
    setInput((prev) => ({ ...prev, [field]: numVal }))
  }, [])

  const handleCalculate = useCallback(() => {
    const res = interpretGasometry(input)
    setResult(res)
  }, [input])

  const handleReset = useCallback(() => {
    setInput({
      ph: null, paco2: null, pao2: null, hco3: null, be: null,
      sao2: null, na: null, k: null, cl: null, ca: null,
      lactate: null, glucose: null, hb: null, albumin: null,
      fio2: null, temperature: null,
    })
    setResult(null)
  }, [])

  const getStatus = (field: keyof typeof NORMAL_RANGES) => getInputStatus(input[field], field)

  return (
    <div className="min-h-screen w-full relative">
      <div className="max-w-7xl mx-auto px-4 py-8 md:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-100 mb-3 tracking-tight">
            Arterial Blood Gas
          </h1>
          <p className="text-lg text-cyan-400/80 font-medium mb-2">Calculator & Interpretation</p>
          <p className="text-sm text-slate-500 max-w-xl mx-auto">
            Enter the patient's blood gas values to receive a comprehensive acid-base and oxygenation analysis with severity scoring.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Panel */}
          <div className="space-y-6">
            {/* Essential ABG */}
            <SectionCard title="Essential ABG" icon={<Activity className="h-5 w-5" />}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <InputField
                  label="pH"
                  unit=""
                  value={input.ph?.toString() ?? ''}
                  onChange={(v) => updateField('ph', v)}
                  status={getStatus('ph')}
                  normalRange="7.35 - 7.45"
                  icon={<FlaskConical className="h-3.5 w-3.5" />}
                />
                <InputField
                  label="PaCO₂"
                  unit="mmHg"
                  value={input.paco2?.toString() ?? ''}
                  onChange={(v) => updateField('paco2', v)}
                  status={getStatus('paco2')}
                  normalRange="35 - 45"
                  icon={<Wind className="h-3.5 w-3.5" />}
                />
                <InputField
                  label="PaO₂"
                  unit="mmHg"
                  value={input.pao2?.toString() ?? ''}
                  onChange={(v) => updateField('pao2', v)}
                  status={getStatus('pao2')}
                  normalRange="80 - 100"
                  icon={<Droplets className="h-3.5 w-3.5" />}
                />
                <InputField
                  label="HCO₃⁻"
                  unit="mEq/L"
                  value={input.hco3?.toString() ?? ''}
                  onChange={(v) => updateField('hco3', v)}
                  status={getStatus('hco3')}
                  normalRange="22 - 26"
                  icon={<FlaskConical className="h-3.5 w-3.5" />}
                />
                <InputField
                  label="Base Excess"
                  unit="mEq/L"
                  value={input.be?.toString() ?? ''}
                  onChange={(v) => updateField('be', v)}
                  status={getStatus('be')}
                  normalRange="-2 to +2"
                  icon={<Activity className="h-3.5 w-3.5" />}
                />
                <InputField
                  label="SaO₂"
                  unit="%"
                  value={input.sao2?.toString() ?? ''}
                  onChange={(v) => updateField('sao2', v)}
                  status={getStatus('sao2')}
                  normalRange="≥ 95%"
                  icon={<Droplets className="h-3.5 w-3.5" />}
                />
              </div>
            </SectionCard>

            {/* FiO2 & Temperature */}
            <SectionCard title="Ventilation & Environment" icon={<Wind className="h-5 w-5" />}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <InputField
                  label="FiO₂"
                  unit="%"
                  value={input.fio2?.toString() ?? ''}
                  onChange={(v) => updateField('fio2', v)}
                  status={getStatus('fio2')}
                  normalRange="21% (room air)"
                  icon={<Wind className="h-3.5 w-3.5" />}
                />
                <InputField
                  label="Temperature"
                  unit="°C"
                  value={input.temperature?.toString() ?? ''}
                  onChange={(v) => updateField('temperature', v)}
                  status={getStatus('temperature')}
                  normalRange="36.5 - 37.5"
                  icon={<Activity className="h-3.5 w-3.5" />}
                />
              </div>
            </SectionCard>

            {/* Electrolytes */}
            <SectionCard title="Electrolytes" icon={<FlaskConical className="h-5 w-5" />}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <InputField
                  label="Sodium"
                  unit="mEq/L"
                  value={input.na?.toString() ?? ''}
                  onChange={(v) => updateField('na', v)}
                  status={getStatus('na')}
                  normalRange="135 - 145"
                />
                <InputField
                  label="Potassium"
                  unit="mEq/L"
                  value={input.k?.toString() ?? ''}
                  onChange={(v) => updateField('k', v)}
                  status={getStatus('k')}
                  normalRange="3.5 - 5.0"
                />
                <InputField
                  label="Chloride"
                  unit="mEq/L"
                  value={input.cl?.toString() ?? ''}
                  onChange={(v) => updateField('cl', v)}
                  status={getStatus('cl')}
                  normalRange="98 - 106"
                />
                <InputField
                  label="Calcium"
                  unit="mmol/L"
                  value={input.ca?.toString() ?? ''}
                  onChange={(v) => updateField('ca', v)}
                  status={getStatus('ca')}
                  normalRange="2.2 - 2.6"
                />
              </div>
            </SectionCard>

            {/* Additional Labs */}
            <SectionCard title="Additional Labs" icon={<Activity className="h-5 w-5" />}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <InputField
                  label="Lactate"
                  unit="mmol/L"
                  value={input.lactate?.toString() ?? ''}
                  onChange={(v) => updateField('lactate', v)}
                  status={getStatus('lactate')}
                  normalRange="0.5 - 1.6"
                />
                <InputField
                  label="Glucose"
                  unit="mg/dL"
                  value={input.glucose?.toString() ?? ''}
                  onChange={(v) => updateField('glucose', v)}
                  status={getStatus('glucose')}
                  normalRange="70 - 100"
                />
                <InputField
                  label="Hemoglobin"
                  unit="g/dL"
                  value={input.hb?.toString() ?? ''}
                  onChange={(v) => updateField('hb', v)}
                  status={getStatus('hb')}
                  normalRange="12 - 16"
                />
                <InputField
                  label="Albumin"
                  unit="g/dL"
                  value={input.albumin?.toString() ?? ''}
                  onChange={(v) => updateField('albumin', v)}
                  status={getStatus('albumin')}
                  normalRange="3.5 - 5.0"
                />
              </div>
            </SectionCard>

            <div className="flex gap-3">
              <Button
                onClick={handleCalculate}
                className="flex-1 bg-cyan-600 hover:bg-cyan-500 text-white font-medium h-11"
              >
                <Activity className="h-4 w-4 mr-2" />
                Calculate & Interpret
              </Button>
              <Button
                onClick={handleReset}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-slate-100 h-11"
              >
                Reset
              </Button>
            </div>
          </div>

          {/* Results Panel */}
          <div className="space-y-6">
            {result ? (
              <>
                {/* Severity Score */}
                <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base font-semibold text-slate-200 flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-amber-400" />
                      Severity Score
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="relative w-24 h-24">
                        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                          <circle cx="50" cy="50" r="42" fill="none" stroke="#1e293b" strokeWidth="8" />
                          <circle
                            cx="50" cy="50" r="42" fill="none"
                            stroke={result.severity.severity === 'Critical' ? '#ef4444' : result.severity.severity === 'Severe' ? '#f97316' : result.severity.severity === 'Moderate' ? '#f59e0b' : '#10b981'}
                            strokeWidth="8"
                            strokeDasharray={`${(result.severity.totalScore / 23) * 264} 264`}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <span className="text-2xl font-bold text-slate-100">{result.severity.totalScore}</span>
                          <span className="text-xs text-slate-500">/ 23</span>
                        </div>
                      </div>
                      <div className="flex-1">
                        <Badge
                          className={`text-sm px-3 py-1 mb-2 ${
                            result.severity.severity === 'Critical' ? 'bg-red-500/20 text-red-400 border-red-500/40' :
                            result.severity.severity === 'Severe' ? 'bg-orange-500/20 text-orange-400 border-orange-500/40' :
                            result.severity.severity === 'Moderate' ? 'bg-amber-500/20 text-amber-400 border-amber-500/40' :
                            'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                          }`}
                        >
                          {result.severity.severity}
                        </Badge>
                        <p className="text-sm text-slate-400">{result.severity.riskClass}</p>
                        <p className="text-xs text-slate-500 mt-1">{result.severity.mortalityRisk}</p>
                      </div>
                    </div>

                    <Separator className="bg-slate-700/50 my-4" />

                    <div className="space-y-3">
                      {result.severity.components.map((comp) => (
                        <ScoreGauge
                          key={comp.name}
                          label={comp.name}
                          score={comp.score}
                          maxScore={comp.maxScore}
                          color={comp.score > 0 ? 'text-amber-400' : 'text-emerald-400'}
                        />
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Acid-Base Results */}
                <SectionCard title="Acid-Base Analysis" icon={<FlaskConical className="h-5 w-5" />}>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Badge
                        className={`${
                          result.acidBase.phStatus === 'acidemia' ? 'bg-red-500/20 text-red-400 border-red-500/40' :
                          result.acidBase.phStatus === 'alkalemia' ? 'bg-blue-500/20 text-blue-400 border-blue-500/40' :
                          'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                        }`}
                      >
                        pH {result.acidBase.phStatus}
                      </Badge>
                      <span className="text-sm text-slate-300 font-medium">{result.acidBase.primaryDisorder}</span>
                    </div>

                    {result.acidBase.mixedDisorder && (
                      <div className="flex items-center gap-2 p-2 rounded bg-red-500/10 border border-red-500/20">
                        <AlertTriangle className="h-4 w-4 text-red-400 shrink-0" />
                        <span className="text-sm text-red-300">Mixed acid-base disorder detected</span>
                      </div>
                    )}

                    <div className="space-y-1.5">
                      <p className="text-sm text-slate-400">Type: <span className="text-slate-200">{result.acidBase.disorderType}</span></p>
                      <p className="text-sm text-slate-400">Compensation: <span className="text-slate-200">{result.acidBase.compensation}</span></p>
                      {result.acidBase.compensationExpected && (
                        <p className="text-sm text-slate-500">Expected: {result.acidBase.compensationExpected}</p>
                      )}
                    </div>

                    {result.acidBase.anionGap !== null && (
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                          <p className="text-xs text-slate-500">Anion Gap</p>
                          <p className={`text-lg font-semibold ${result.acidBase.anionGap > 16 ? 'text-red-400' : result.acidBase.anionGap >= 8 ? 'text-emerald-400' : 'text-amber-400'}`}>
                            {result.acidBase.anionGap.toFixed(1)}
                          </p>
                        </div>
                        {result.acidBase.correctedAnionGap !== null && (
                          <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                            <p className="text-xs text-slate-500">Corrected AG</p>
                            <p className={`text-lg font-semibold ${result.acidBase.correctedAnionGap > 16 ? 'text-red-400' : 'text-emerald-400'}`}>
                              {result.acidBase.correctedAnionGap.toFixed(1)}
                            </p>
                          </div>
                        )}
                        {result.acidBase.deltaRatio !== null && (
                          <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                            <p className="text-xs text-slate-500">Delta Ratio</p>
                            <p className="text-lg font-semibold text-cyan-400">{result.acidBase.deltaRatio.toFixed(2)}</p>
                          </div>
                        )}
                        {result.acidBase.winterPrediction !== null && (
                          <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                            <p className="text-xs text-slate-500">Winter's PaCO₂</p>
                            <p className="text-lg font-semibold text-cyan-400">{result.acidBase.winterPrediction.toFixed(1)}</p>
                          </div>
                        )}
                      </div>
                    )}

                    <ScrollArea className="h-auto max-h-40">
                      <div className="space-y-1.5">
                        {result.acidBase.interpretation.map((item, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm">
                            <Info className="h-3.5 w-3.5 text-cyan-400/70 mt-0.5 shrink-0" />
                            <span className="text-slate-300">{item}</span>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </SectionCard>

                {/* Oxygenation Results */}
                <SectionCard title="Oxygenation Analysis" icon={<Droplets className="h-5 w-5" />}>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Badge
                        className={`${
                          result.oxygenation.oxygenationStatus.includes('Critical') ? 'bg-red-500/20 text-red-400 border-red-500/40' :
                          result.oxygenation.oxygenationStatus.includes('Severe') ? 'bg-orange-500/20 text-orange-400 border-orange-500/40' :
                          result.oxygenation.oxygenationStatus.includes('Moderate') ? 'bg-amber-500/20 text-amber-400 border-amber-500/40' :
                          result.oxygenation.oxygenationStatus.includes('Mild') ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40' :
                          'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                        }`}
                      >
                        {result.oxygenation.oxygenationStatus}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {result.oxygenation.aaGradient !== null && (
                        <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                          <p className="text-xs text-slate-500">A-a Gradient</p>
                          <p className={`text-lg font-semibold ${result.oxygenation.aaGradientElevated ? 'text-red-400' : 'text-emerald-400'}`}>
                            {result.oxygenation.aaGradient.toFixed(1)}
                          </p>
                        </div>
                      )}
                      {result.oxygenation.pfRatio !== null && (
                        <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                          <p className="text-xs text-slate-500">P/F Ratio</p>
                          <p className={`text-lg font-semibold ${result.oxygenation.pfRatio < 300 ? 'text-red-400' : 'text-emerald-400'}`}>
                            {result.oxygenation.pfRatio.toFixed(0)}
                          </p>
                        </div>
                      )}
                      {result.oxygenation.paO2 !== null && (
                        <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                          <p className="text-xs text-slate-500">PAO₂</p>
                          <p className="text-lg font-semibold text-cyan-400">{result.oxygenation.paO2.toFixed(1)}</p>
                        </div>
                      )}
                      {result.oxygenation.shuntFraction !== null && (
                        <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                          <p className="text-xs text-slate-500">Shunt Fraction</p>
                          <p className="text-lg font-semibold text-cyan-400">{(result.oxygenation.shuntFraction * 100).toFixed(1)}%</p>
                        </div>
                      )}
                    </div>

                    <ScrollArea className="h-auto max-h-40">
                      <div className="space-y-1.5">
                        {result.oxygenation.oxygenationInterpretation.map((item, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm">
                            <Info className="h-3.5 w-3.5 text-cyan-400/70 mt-0.5 shrink-0" />
                            <span className="text-slate-300">{item}</span>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </SectionCard>

                {/* Electrolyte Results */}
                <SectionCard title="Electrolyte Analysis" icon={<Activity className="h-5 w-5" />}>
                  <div className="space-y-3">
                    {result.electrolytes.anionGap !== null && (
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                          <p className="text-xs text-slate-500">Anion Gap</p>
                          <p className={`text-lg font-semibold ${result.electrolytes.anionGap > 16 ? 'text-red-400' : 'text-emerald-400'}`}>
                            {result.electrolytes.anionGap.toFixed(1)}
                          </p>
                        </div>
                        {result.electrolytes.correctedAnionGap !== null && (
                          <div className="p-2 rounded bg-slate-800/50 border border-slate-700/50">
                            <p className="text-xs text-slate-500">Corrected AG</p>
                            <p className={`text-lg font-semibold ${result.electrolytes.correctedAnionGap > 16 ? 'text-red-400' : 'text-emerald-400'}`}>
                              {result.electrolytes.correctedAnionGap.toFixed(1)}
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    <ScrollArea className="h-auto max-h-40">
                      <div className="space-y-1.5">
                        {result.electrolytes.electrolyteInterpretation.length > 0 ? (
                          result.electrolytes.electrolyteInterpretation.map((item, i) => (
                            <div key={i} className="flex items-start gap-2 text-sm">
                              <AlertTriangle className="h-3.5 w-3.5 text-amber-400/70 mt-0.5 shrink-0" />
                              <span className="text-slate-300">{item}</span>
                            </div>
                          ))
                        ) : (
                          <div className="flex items-start gap-2 text-sm">
                            <CheckCircle className="h-3.5 w-3.5 text-emerald-400/70 mt-0.5 shrink-0" />
                            <span className="text-slate-400">No significant electrolyte abnormalities detected</span>
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </div>
                </SectionCard>

                {/* Overall Interpretation */}
                <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base font-semibold text-slate-200 flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-cyan-400" />
                      Clinical Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {result.overallInterpretation.length > 0 ? (
                        result.overallInterpretation.map((item, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm">
                            <span className="text-cyan-400 mt-0.5 shrink-0">•</span>
                            <span className="text-slate-300">{item}</span>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-slate-400">No significant abnormalities detected. Values are within normal limits.</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm h-full min-h-[400px] flex items-center justify-center">
                <div className="text-center p-8">
                  <Activity className="h-12 w-12 text-slate-600 mx-auto mb-4" />
                  <p className="text-lg text-slate-400 font-medium mb-2">Enter blood gas values</p>
                  <p className="text-sm text-slate-500 max-w-xs mx-auto">
                    Fill in the parameters on the left and click "Calculate & Interpret" to see the analysis results.
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <Separator className="bg-slate-700/30 mb-6" />
          <p className="text-xs text-slate-600">
            This calculator is for educational and clinical decision support purposes only.
            Always correlate with clinical findings and consult appropriate references.
          </p>
        </div>
      </div>
    </div>
  )
}
